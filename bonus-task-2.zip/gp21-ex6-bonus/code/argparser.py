from comet_ml import Experiment

import argparse
import os
import os.path as op
import torch

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--train",
        action='store_true',
        help="Train a model (see --use_model)"
    )
    parser.add_argument(
        "--eval",
        action='store_true',
        help="Evaluate a saved model (see --load)"
    )
    parser.add_argument(
        "--export",
        type=str,
        nargs="+",
        choices=["original", "o", "model", "m", "features", "f", "reconstructed", "r"],
        help="Export data related to model (requires --load)"
    )

    # arguments for training
    parser.add_argument(
        "--num_epoch",
        type=int,
        default=200,
        help="Number of epochs to train"
    )
    parser.add_argument(
        "--num_features",
        type=int,
        default=16,
        help="Number of features for latent variable"
    )
    parser.add_argument(
        "--lr",
        type=float,
        default=1e-4,
        help='Learning rate'
    )
    parser.add_argument(
        "--batch_size",
        type=int,
        default=4,
        help="Batch size"
    )
    parser.add_argument(
        "--num_workers",
        type=int,
        default=0,
        help='Number of workers used in dataloader'
    )
    parser.add_argument(
        "--log_mesh_every",
        type=int,
        default=25,
        help="Log 3d points every number of step"
    )
    parser.add_argument(
        "--lambda_kld",
        type=float,
        default=1e-4,
        help='Weight of KL divergence wrt reconstruction loss'
    )

    # arguments for testing
    parser.add_argument(
        "--load",
        type=str,
        default="",
        help="Load saved model: [ vae | $EXP_KEY ]"
    )

    args = parser.parse_args()
    return args

args = parse_args()
