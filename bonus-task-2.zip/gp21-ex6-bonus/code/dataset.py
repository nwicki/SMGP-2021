from comet_ml import Experiment

import torch
import os
from os.path import isfile, join
import numpy as np
import matplotlib.pyplot as plt
from torch.utils.data import Dataset, DataLoader
from pytorch3d.io import load_obj, save_obj

class FaceDataset(Dataset):
    """Dataset of face meshes"""

    def __init__(self, path):
        self.path = path
        self.mesh_list = [f for f in os.listdir(path) if isfile(join(path, f)) and f.endswith(".obj")]
        mesh = load_obj(join(self.path, self.mesh_list[0]))
        self.faces = mesh[1].verts_idx

    def __len__(self):
        return len(self.mesh_list)

    def __getitem__(self, index):
        mesh_path = join(self.path, self.mesh_list[index])
        mesh = load_obj(mesh_path)
        v = mesh[0].view(-1,1).squeeze()
        return v

# val_dataset = FaceDataset("eval/")
# val_dataloader = torch.utils.data.dataloader.DataLoader(val_dataset, batch_size=4, shuffle=False, num_workers=0, drop_last=False, pin_memory=True)
# print(next(iter(val_dataloader)).shape)