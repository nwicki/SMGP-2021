from comet_ml import Experiment

import torch
from torch import nn, optim
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm, trange

from dataset import FaceDataset
from model import VAEModel
from utils import export_meshes
from pytorch3d.io import load_obj, save_obj

import os
from os.path import isfile, join, splitext

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print('Using {} device'.format(device))


def train_model(args):
    experiment = Experiment()
    print(f"\nTraining VAE model for {args.num_epoch} epochs (exp_key = {experiment.get_key()[:9]})...")
    # initialize training set and dataloader
    train_dataset = FaceDataset("train/")
    train_dataloader = torch.utils.data.dataloader.DataLoader(
                    train_dataset, batch_size=args.batch_size, shuffle=True, 
                    num_workers=args.num_workers, drop_last=True, pin_memory=True)

    # initialize validation set and dataloader
    val_dataset = FaceDataset("eval/")
    val_dataloader = torch.utils.data.dataloader.DataLoader(
                    val_dataset, batch_size=len(val_dataset), shuffle=False, 
                    num_workers=args.num_workers, drop_last=False, pin_memory=True)
    
    # define sample batch for evaluation & visualization (train and eval)
    train_eval_batch = next(iter(train_dataloader))
    val_eval_batch = next(iter(val_dataloader)) # whole eval set

    # define model
    model = VAEModel(nf = args.num_features).to(device)
    model.train()

    # define training loss and optimizer
    rec_loss_fn = nn.L1Loss().to(device) # reconstruction loss
    kld_loss_fn = lambda mu, log_var: (- 0.5 * args.lambda_kld * torch.sum(1 + log_var - mu.pow(2) - log_var.exp())).to(device) # KL-divergence loss
    optimizer = optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=args.lr)

    # log hyperparameters
    experiment.log_parameters(args)
    
    step = 0
    for epoch in range(args.num_epoch):
        experiment.set_epoch(epoch)
        running_loss = np.array([0.0, 0.0, 0.0])
        pbar = tqdm(enumerate(train_dataloader), total=len(train_dataloader))
        pbar.set_description(f'Epoch {epoch} ')
        for _, batch in pbar:
            # get current batch and put to device
            batch = batch.to(device)

            # reset the gradient
            optimizer.zero_grad()

            # forward pass through the model
            rec, mu, log_var = model(batch)

            # compute the loss
            rec_loss = rec_loss_fn(rec, batch)
            kld_loss = kld_loss_fn(mu, log_var)
            loss = rec_loss + kld_loss

            # backpropagation
            loss.backward()

            # log the metrics, images, etc  
            with torch.no_grad():
                # log training loss
                running_loss += np.array([rec_loss.item(), kld_loss.item(), loss.item()])
                pbar.set_postfix({'rec_loss': rec_loss.item(), 'kld_loss': kld_loss.item(), 'loss': loss.item()})
                if step % len(train_dataloader) == len(train_dataloader) - 1:
                    experiment.log_metric("Rec loss (train) ", running_loss[0] / len(train_dataloader), step=step)
                    experiment.log_metric("KLD loss (train) ", running_loss[1] / len(train_dataloader), step=step)
                    experiment.log_metric("Total loss (train) ", running_loss[2] / len(train_dataloader), step=step)
                    pbar.set_postfix({  'rec_loss': running_loss[0] / len(train_dataloader), 
                                        'kld_loss': running_loss[1] / len(train_dataloader), 
                                        'loss': running_loss[2] / len(train_dataloader)})
                    running_loss = np.array([0.0, 0.0, 0.0])

                # log evaluation losses on sample evaluation batch
                if step % len(train_dataloader) == len(train_dataloader) - 1:
                    val_rec, val_mu, val_log_var = model(val_eval_batch)
                    val_rec_loss = rec_loss_fn(val_rec, val_eval_batch)
                    val_kld_loss = kld_loss_fn(val_mu, val_log_var)
                    val_loss = val_rec_loss + val_kld_loss
                    experiment.log_metric("Rec loss (eval) ", val_rec_loss, step=step)
                    experiment.log_metric("KLD loss (eval) ", val_kld_loss, step=step)
                    experiment.log_metric("Total loss (eval) ", val_loss, step=step)

                # log images (low res, bilinear, bicubic, CNN and high res ground truth)
                if step % args.log_mesh_every == args.log_mesh_every - 1:
                    # compute forward pass on sample training batch and log images
                    train_rec, train_mu, train_log_var = model(train_eval_batch)
                    export_meshes(experiment, step, train_rec, train_dataset.faces, 'Train')

                    # log images from validation sample batch
                    export_meshes(experiment, step, val_rec, val_dataset.faces, 'Eval')
                
            # update the model parameters
            optimizer.step()
            step += 1

        # save network
        torch.save({'args':args,
                    'model_state_dict':model.state_dict()}, 'saved_models/model_%s.pt'%(experiment.get_key()[:9]))


def eval_model(args):
    torch.manual_seed(0)
    # load model
    pt = torch.load('saved_models/model_%s.pt'%(args.load), map_location=torch.device(device))
    pt_args = pt['args']
    model = VAEModel(nf = pt_args.num_features).to(device)
    model.load_state_dict(pt['model_state_dict'])
    model.eval()

    print(f'\nEvaluating model_{args.load} on eval dataset...\n')

    # initialize validation set and dataloader
    val_dataset = FaceDataset("eval/")
    val_dataloader = torch.utils.data.dataloader.DataLoader(
                    val_dataset, batch_size=len(val_dataset), shuffle=False, 
                    num_workers=args.num_workers, drop_last=False, pin_memory=True)
    val_batch = next(iter(val_dataloader)) # whole eval set

    # define evaluation losses
    rec_loss_fn = nn.L1Loss().to(device) # reconstruction loss
    kld_loss_fn = lambda mu, log_var: (- 0.5 * pt_args.lambda_kld * torch.sum(1 + log_var - mu.pow(2) - log_var.exp())).to(device) # KL-divergence loss

    with torch.no_grad():
        val_batch = val_batch.to(device)
        val_rec, val_mu, val_log_var = model(val_batch)
        val_rec_loss = rec_loss_fn(val_rec, val_batch)
        val_kld_loss = kld_loss_fn(val_mu, val_log_var)
        val_loss = val_rec_loss + val_kld_loss
        row_format ="{:>15}" * 4
        print(row_format.format('', 'Rec loss', 'KLD loss', 'Total loss'))
        res_loss = []
        for loss, loss_name in zip([val_rec_loss, val_kld_loss, val_loss], ['Rec loss', 'KLD loss', 'Total loss']):
            res_loss += [round(loss.item(), 3)]
        print(row_format.format('VAE model', *res_loss))
        print('\n')


def export_for_cpp(args):
    # load model
    pt = torch.load('saved_models/model_%s.pt'%(args.load), map_location=torch.device(device))
    pt_args = pt['args']
    model = VAEModel(nf = pt_args.num_features).to(device)
    model.load_state_dict(pt['model_state_dict'])
    model.eval()

    print(f'\nExport data in train and eval dataset using model {args.load}...\n')

    # export model weights and biases in txt format for c++
    if "model" in args.export or "m" in args.export:
        if not os.path.exists("vae_faces/model/"):
            os.makedirs("vae_faces/model/")
        for layer in ['enc1', 'enc2', 'enc_mu', 'enc_var', 'dec1', 'dec2', 'dec3']:
            for wb in ['weight', 'bias']:
                save_layer_path = f'vae_faces/model/{layer}_{wb}.txt'
                print(f'Exporting {layer}.{wb} to {save_layer_path}')
                mat = pt['model_state_dict'][f'{layer}.{wb}'].detach().numpy()
                if wb == 'weight':
                    with open(save_layer_path, "w") as f:
                        f.write(str(mat.shape[0]) + " " + str(mat.shape[1]) + "\n")
                        for i in range(mat.shape[0]):
                            for j in range(mat.shape[1]):
                                f.write(str(mat[i,j]) + " ")
                            f.write("\n")
                else:
                    with open(save_layer_path, "w") as f:
                        f.write(str(mat.shape[0]) + " 1\n")
                        for i in range(mat.shape[0]):
                            f.write(str(mat[i]) + "\n")

    # initialize training and validation set
    train_dataset = FaceDataset("train/")
    val_dataset = FaceDataset("eval/")

    # create dir if not exist
    if not os.path.exists("vae_faces/train/"):
        os.makedirs("vae_faces/train/")
    if not os.path.exists("vae_faces/eval/"):
        os.makedirs("vae_faces/eval/")

    # export data for c++
    for dataset in [train_dataset, val_dataset]:
        for mesh_name in dataset.mesh_list:
            mesh = load_obj(join(dataset.path, mesh_name))
            vertices = mesh[0].view(-1,1).squeeze().to(device)
            rec, mu, log_var = model(vertices)
            if "original" in args.export or "o" in args.export:
                save_o_path = f'vae_faces/{dataset.path}{mesh_name}'
                save_obj(save_o_path, mesh[0], dataset.faces)
                print("Exporting original mesh to", save_o_path)
            if "features" in args.export or "f" in args.export:
                save_z_path = f'vae_faces/{dataset.path}{splitext(mesh_name)[0]}_features.txt'
                with open(save_z_path, "w") as f:
                    f.write("\n".join(str(i) for i in model.z.detach().numpy()))
                print("Exporting latent variable to", save_z_path)
            if "reconstructed" in args.export or "r" in args.export:
                save_r_path = f'vae_faces/{dataset.path}{splitext(mesh_name)[0]}_vae.obj'
                save_obj(save_pr_ath, rec.view(-1, 3), dataset.faces)
                print("Exporting reconstructed mesh to", save_r_path)


if __name__ == "__main__":
    from argparser import args
    if args.train:
        train_model(args)
    elif args.eval:
        eval_model(args)
    elif args.export != []:
        export_for_cpp(args)