from comet_ml import Experiment

import torch
from torch import nn
import numpy as np
import matplotlib.pyplot as plt
from torchsummary import summary

class VAEModel(nn.Module):
    """Basic VAE Model"""

    def __init__(self, in_size = 3*2319, nf = 16):
        super().__init__()
        
        # encoder
        self.enc1 = nn.Linear(in_features=in_size, out_features=512)
        self.enc2 = nn.Linear(in_features=512, out_features=128)
        self.enc_mu = nn.Linear(in_features=128, out_features=nf)
        self.enc_var = nn.Linear(in_features=128, out_features=nf)

        # decoder
        self.dec1 = nn.Linear(in_features=nf, out_features=128)
        self.dec2 = nn.Linear(in_features=128, out_features=512)
        self.dec3 = nn.Linear(in_features=512, out_features=in_size)
    
    def sampling(self, mu, log_var):
        std = torch.exp(0.5*log_var)
        eps = torch.randn_like(std)
        return eps.mul(std).add_(mu)
        
    def forward(self, x):
        # encoding
        x = nn.functional.relu(self.enc1(x))
        x = nn.functional.relu(self.enc2(x))
        mu = self.enc_mu(x)
        log_var = self.enc_var(x)

        # reparametrize
        self.z = self.sampling(mu, log_var)

        # decoding
        x = nn.functional.relu(self.dec1(self.z))
        x = nn.functional.relu(self.dec2(x))
        rec = self.dec3(x)

        return rec, mu, log_var

# model = VAEModel()
# summary(model, (1, 3*2319))