from comet_ml import Experiment

import torch
from torch import nn, optim
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm, trange
from pytorch3d.io import load_obj, save_obj

def export_meshes(experiment, step, batch, faces, split='Train'):
    batch_size = batch.shape[0]
    for i in range(batch_size):
        save_obj(f'tmp/{split}_{i}_{step}.obj', batch[i].view(-1, 3), faces)
        experiment.log_asset(f'tmp/{split}_{i}_{step}.obj', f'{split}_{i}_{step}', step=step)
        experiment.log_points_3d(f'{split}_{i}', points = batch[i].view(-1, 3), step=step)

