#!/bin/bash

module load gcc/6.3.0 python_gpu/3.8.5 cuda/10.1.243 cudnn/7.6.4 eth_proxy

if [ ! -d "venv/" ]; then
    python3 -m venv venv
    echo "Created virtual environment."
fi

source venv/bin/activate
pip3 install -r requirements.txt
